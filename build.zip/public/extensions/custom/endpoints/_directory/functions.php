<?php

if (!function_exists('example_get_data')) {
    /**
     * @return array
     */
    function example_get_data()
    {
        return [
            'item 1',
            'item 2'
        ];
    }
}

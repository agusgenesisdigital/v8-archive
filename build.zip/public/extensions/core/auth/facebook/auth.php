<?php

return [
    'provider' => \Directus\Authentication\Sso\Provider\facebook\Provider::class
];

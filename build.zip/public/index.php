<?php

$app = require __DIR__ . '/../src/web.php';

$app->run();
